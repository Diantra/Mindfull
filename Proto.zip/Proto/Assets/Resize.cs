﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Resize : MonoBehaviour
{
    private Transform _transfrom;
    // Start is called before the first frame update
    void Start()
    {
        _transfrom = GetComponent<Transform>();
        OnResize();
    }

    private void OnResize()
    {
        _transfrom.localScale = new Vector3(1.5f, 1.5f, 3f);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
